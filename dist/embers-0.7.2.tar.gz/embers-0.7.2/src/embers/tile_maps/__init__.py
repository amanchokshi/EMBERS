"""
:mod:`embers.tile_maps` is used to create tile maps by aggregating satellite data

It contains :mod:`~embers.tile_maps.beam_utils`, :mod:`~embers.tile_maps.ref_fee_healpix`, :mod:`~embers.tile_maps.tile_maps`,
:mod:`~embers.tile_maps.null_test`, :mod:`~embers.tile_maps.compare_beams`
"""
