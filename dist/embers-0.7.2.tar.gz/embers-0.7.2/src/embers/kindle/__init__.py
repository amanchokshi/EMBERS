"""
:mod:`embers.kindle` contains a set of executable script to process data in various ways

"""
