"""
:mod:`embers.rf_tools` is used to pre process, condition and preview raw rf data.

It contains :mod:`~embers.rf_tools.rf_data`, :mod:`~embers.rf_tools.align_data`, :mod:`~embers.rf_tools.colormaps` modules.

"""
